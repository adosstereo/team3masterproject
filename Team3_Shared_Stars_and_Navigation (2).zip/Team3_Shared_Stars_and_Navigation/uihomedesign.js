let gameTitle = "Welcome!";

let cream, sky, navy, yellow, pink, blue, white, green;

let screen = "home";
let showHelp = false;
let barHeight = 70;

// makes everything fit the window
let pageScale = 1;
let pageX = 0;
let pageY = 0;
let pointerX = 0;
let pointerY = 0;

let gamesButton, shopButton, exitButton;
let homeButton, backButton, helpButton;
let screenHistory = [];
let shapeButton, vegetableButton, cookieMenuButton, bubbleMenuButton;

function setup() {
  createCanvas(windowWidth, windowHeight);

  cream = color("#F1FADF");
  sky = color("#2BD9EE");
  navy = color("#17375E");
  yellow = color("#FFD43B");
  pink = color("#F26BAA");
  blue = color("#3D8BFF");
  white = color("#FFFFFF");
  green = color("#A5DF57");

  gamesButton = makeButton(
    400, 340, 280, 100, "Games", sky, 36, "play"
  );

  exitButton = makeButton(
    110, 535, 170, 64, "Exit", white, 26, "none"
  );

  shopButton = makeButton(
    690, 535, 170, 64, "Shop", white, 26, "star"
  );

  homeButton = makeButton(
    90, 35, 130, 46, "Home", white, 22, "none"
  );

  backButton = makeButton(
    215, 35, 100, 46, "Back", white, 20, "none"
  );

  helpButton = makeButton(
    740, 35, 60, 46, "?", yellow, 26, "none"
  );

  shapeButton = makeButton(
    220, 285, 320, 100, "Shape Sorter", white, 27, "none"
  );

  vegetableButton = makeButton(
    580, 285, 320, 100, "Vegetable Shinobi", white, 25, "none"
  );

  cookieMenuButton = makeButton(
    220, 455, 320, 100, "Cookie Trace", pink, 27, "none"
  );

  bubbleMenuButton = makeButton(
    580, 455, 320, 100, "Bubble Rhythm", sky, 27, "none"
  );

  // sets up both games
  loadShopSave();
  loadShopImages();
  setupBubbleGame();
  setupCookieGame();
  if (new URLSearchParams(window.location.search).get("page") === "games") screen = "games";

  updatePageSize();
}

function draw() {
  stars = TeamStars.balance();
  drawMainBackground();
  updatePointer();

  // keeps everything lined up when the window changes
  push();
  translate(pageX, pageY);
  scale(pageScale);

  if (screen === "home") {
    drawHome();
  } else if (screen === "games") {
    drawGames();
  } else if (screen === "shop") {
    drawShop();
  } else if (screen === "exit") {
    drawExit();
  } else if (isCookieScreen()) {
    drawCookieScreens();
  } else if (isBubbleScreen()) {
    drawBubbleScreens();
  } else if (["shape", "ninja"].includes(screen)) {
    drawGamePlaceholder();
  }

  if (showHelp) {
    drawHelp();
  }

  pop();
}

function drawHome() {
  drawTopBar("", false);

  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(48);
  text(gameTitle, 400, 150);

  drawShapes(400, 220);

  drawButton(gamesButton);
  drawButton(exitButton);
  drawButton(shopButton);
}

function drawGames() {
  drawTopBar("Games", true);
  // The shop wallpaper stays visible behind the four game logos.
  drawGameTile(200, 175, "#9fe04f", "shape");
  drawGameTile(450, 175, "#d49a9a", "ninja");
  drawGameTile(200, 375, "#f0d583", "cookie");
  drawGameTile(450, 375, "#66d3ea", "bubble");
}

function drawGameTile(x, y, tileColor, key) {
  const hovered = insideButton(x, y, 150, 150);
  push();
  rectMode(CORNER);
  noStroke();
  fill(navy);
  rect(x, y + 6, 150, 150, 12);
  fill(tileColor);
  stroke(navy);
  strokeWeight(2);
  rect(x, y - (hovered ? 3 : 0), 150, 150, 12);

  translate(x, y - (hovered ? 3 : 0));
  const ink = "#1a2a4a";
  if (key === "shape") {
    // Adapted from the supplied Shape Sorter logo.
    stroke(ink); strokeWeight(2);
    fill("#ee6aa7"); circle(40, 57, 37);
    fill("#4f8cf5"); rect(66, 38, 38, 38);
    fill("#f8d05c"); triangle(111, 76, 143, 76, 127, 38);
    noStroke(); fill(ink);
    textFont("Helvetica"); textStyle(BOLD); textSize(20);
    textAlign(CENTER, CENTER);
    text("Shape Sorter", 75, 121);
  } else if (key === "ninja") {
    // Adapted from the supplied Vegetable Shinobi logo.
    stroke(ink); strokeWeight(2); noFill();
    const bob = hovered ? sin(frameCount * 0.2) * 3 : 0;
    line(75, 33 + bob, 80 + (hovered ? sin(frameCount * 0.3) * 4 : 0), 16 + bob);
    fill("#e07bb0"); ellipse(75, 63 + bob, 59, 59);
    noStroke(); fill(ink); textFont("Arial"); textStyle(BOLD);
    textAlign(CENTER, CENTER); textSize(19); textLeading(22);
    text("Vegetable\nShinobi", 75, 120);
  } else if (key === "cookie") {
    // Adapted from the supplied Cookie Trace logo.
    noStroke(); fill("#f8d25a"); circle(75, 61, 80);
    noFill(); stroke("#1e2d55"); strokeWeight(2);
    beginShape();
    for (let i = 0; i < 10; i++) {
      const a = -HALF_PI + i * PI / 5;
      const r = i % 2 === 0 ? 29 : 12;
      vertex(87 + cos(a) * r, 58 + sin(a) * r);
    }
    endShape(CLOSE);
    noStroke(); fill("#1e2d55"); textFont("Helvetica");
    textStyle(BOLD); textSize(21); textAlign(CENTER, CENTER);
    text("Cookie Trace", 75, 122);
  } else if (key === "bubble") {
    // Adapted from the supplied Bubble Rhythm logo.
    const t = frameCount * 0.1;
    noFill(); stroke(ink); strokeWeight(2);
    ellipse(53, 55 + (hovered ? cos(t * 1.5) * 3 : 0),
            43 * (hovered ? 1 + sin(t * 2) * 0.08 : 1));
    ellipse(99, 70 + (hovered ? cos(t * 1.5 + 1.5) * 3 : 0),
            46 * (hovered ? 1 + sin(t * 2 + 1.5) * 0.08 : 1));
    noStroke(); fill(ink); textFont("Arial"); textStyle(BOLD);
    textAlign(CENTER, CENTER); textSize(19);
    text("Bubble Rhythm", 75, 122);
  }
  pop();
}

function drawGamePlaceholder() {
  drawTopBar("Games", true);
  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(35);
  const names = {
    shape: "Shape Sorter",
    ninja: "Vegetable Shinobi",
    cookie: "Cookie Trace",
    bubble: "Bubble Rhythm"
  };
  text(names[screen] || "Game", 400, 235);
  textStyle(NORMAL);
  textSize(23);
  text("Game coming soon!", 400, 315);
  textSize(17);
  text("Use Home to return to the menu.", 400, 360);
}

function drawExit() {
  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(48);
  text("See you next time!", 400, 270);

  textStyle(NORMAL);
  textSize(24);
  text("Tap anywhere to come back", 400, 330);
}


function drawTopBar(title, showHomeButton) {
  let leftEdge = -pageX / pageScale;
  let fullWidth = width / pageScale;

  noStroke();

  if (screen === "home") {
    fill(sky);
  } else {
    fill(blue);
  }

  rect(leftEdge, 0, fullWidth, barHeight);

  stroke(navy);
  strokeWeight(3);
  line(leftEdge, barHeight,
       leftEdge + fullWidth, barHeight);

  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(30);
  text(title, leftEdge + fullWidth / 2, 35);

  if (showHomeButton) {
    drawButton(homeButton);
    drawButton(backButton);
  }

  // Shared star counter with white rounded box
  if (screen !== "shop") {
    let badgeX = helpButton.x - 112;
    let badgeY = 35;

    push();
    rectMode(CENTER);

    // White box and dark blue border
    stroke(navy);
    strokeWeight(3);
    fill(255);
    rect(badgeX, badgeY, 84, 42, 20);

    // Yellow star
    push();
    translate(badgeX - 21, badgeY);
    fill("#FFD966");
    stroke(navy);
    strokeWeight(2);

    beginShape();
    for (let i = 0; i < 10; i++) {
      let angle = -HALF_PI + i * PI / 5;
      let radius = i % 2 === 0 ? 11 : 5;

      vertex(
        cos(angle) * radius,
        sin(angle) * radius
      );
    }
    endShape(CLOSE);
    pop();

    // Shared star balance
    noStroke();
    fill(navy);
    textAlign(CENTER, CENTER);
    textStyle(BOLD);
    textSize(22);
    text(TeamStars.balance(), badgeX + 12, badgeY);

    pop();
  }

  drawButton(helpButton);
}


function drawHelp() {
  push();

  // darkens the background when help is open
  noStroke();
  fill(23, 55, 94, 150);
  rect(
    -pageX / pageScale,
    0,
    width / pageScale,
    height / pageScale
  );

  // rounded help box
  fill(white);
  stroke(navy);
  strokeWeight(3);
  rect(110, 165, 580, 280, 24);

  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(32);
  text("How it works", 400, 215);

  textStyle(NORMAL);
  textSize(23);
  textLeading(35);

  if (screen === "home") {
    text(
      "Tap Games to choose a game.",
      400, 300
    );
  } else if (screen === "games") {
    text(
      "Choose one of the four games.\nGame levels will be added next!",
      400, 300
    );
  } else if (screen === "shop") {
    text(
      "Buy and equip backgrounds using stars.\nUse More to see the next page.",
      400, 300
    );
  }

  textSize(18);
  text("Tap anywhere to close", 400, 405);

  pop();
}

function drawShapes(x, y) {
  // makes the shapes float up and down
  let circleMove = sin(frameCount * 0.05) * 5;
  let squareMove = sin(frameCount * 0.05 + 1) * 5;
  let triangleMove = sin(frameCount * 0.05 + 2) * 5;

  stroke(navy);
  strokeWeight(3);

  fill(pink);
  ellipse(x - 70, y + circleMove, 40, 40);

  fill(blue);
  rectMode(CENTER);
  rect(x, y + squareMove, 38, 38);
  rectMode(CORNER);

  fill(yellow);
  triangle(
    x + 50, y + 20 + triangleMove,
    x + 90, y + 20 + triangleMove,
    x + 70, y - 20 + triangleMove
  );
}

// keeps the button info together
function makeButton(x, y, w, h, label, buttonColor, textSizeValue, icon) {
  return {
    x: x,
    y: y,
    w: w,
    h: h,
    label: label,
    buttonColor: buttonColor,
    textSizeValue: textSizeValue,
    icon: icon,
    scale: 1
  };
}

function drawButton(button) {
  let hovering = isOver(button) && showHelp === false;
  let targetSize = 1;

  if (hovering) {
    targetSize = 1.06;
  }

  // makes the button a little bigger when you hover
  button.scale += (targetSize - button.scale) * 0.2;

  let press = 0;

  if (hovering && mouseIsPressed) {
    press = 4;
  }

  push();
  translate(button.x, button.y);
  scale(button.scale);
  rectMode(CENTER);

  // shadow behind the button
  noStroke();
  fill(navy);
  rect(0, 5, button.w, button.h, 20);

  // the 20 rounds the corners
  stroke(navy);
  strokeWeight(3);
  fill(button.buttonColor);
  rect(0, press, button.w, button.h, 20);

  let textX = 0;
  let iconX = -button.w / 2 + button.h * 0.55;

  if (button.icon === "play") {
    fill(white);

    triangle(
      iconX - 12, press - 16,
      iconX - 12, press + 16,
      iconX + 16, press
    );

    textX = button.h * 0.25;
  } else if (button.icon === "star") {
    fill(yellow);
    drawStar(iconX, press, 8, 18);
    textX = button.h * 0.25;
  }

  noStroke();
  fill(navy);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(button.textSizeValue);
  text(button.label, textX, press);

  pop();
}

function drawStar(x, y, innerRadius, outerRadius) {
  beginShape();

  for (let i = 0; i < 10; i++) {
    let angle = -HALF_PI + i * PI / 5;
    let radius = innerRadius;

    if (i % 2 === 0) {
      radius = outerRadius;
    }

    vertex(
      x + cos(angle) * radius,
      y + sin(angle) * radius
    );
  }

  endShape(CLOSE);
}

function isOver(button) {
  return pointerX > button.x - button.w / 2 &&
         pointerX < button.x + button.w / 2 &&
         pointerY > button.y - button.h / 2 &&
         pointerY < button.y + button.h / 2;
}

function navigateTo(next) {
  if (screen !== next) {
    screenHistory.push(screen);
    screen = next;
  }
}

function goHome() {
  cookieTracing = false;
  bubbleRunning = false;
  screen = "home";
  screenHistory = [];
}

function goBack() {
  cookieTracing = false;
  bubbleRunning = false;
  if (isCookieScreen() || isBubbleScreen()) {
    screen = "games";
    screenHistory = ["home"];
    return;
  }
  screen = screenHistory.length ? screenHistory.pop() : "home";
}

function mousePressed() {
  updatePointer();

  if (showHelp) {
    showHelp = false;
    return false;
  }

  // Home always returns to the main homepage, even from a game.
  if (screen !== "home" && isOver(homeButton)) {
    goHome();
    return false;
  }

  // Back returns to the previous page.
  if (screen !== "home" && isOver(backButton)) {
    goBack();
    return false;
  }

  if (isOver(helpButton)) {
    showHelp = true;
    return false;
  }

  if (screen === "shop") {
    if (!purchaseAnimation) handleShopClick();
    return false;
  }

  if (screen === "exit") {
    goHome();
    return false;
  }

  if (screen === "games") {
    if (insideButton(200, 175, 150, 150)) window.location.href = "shape-sorter/index.html";
    else if (insideButton(450, 175, 150, 150)) window.location.href = "vegetable-shinobi/index.html";
    else if (insideButton(200, 375, 150, 150)) navigateTo("cookieMenu");
    else if (insideButton(450, 375, 150, 150)) navigateTo("bubbleMenu");
    return false;
  }

  if (isCookieScreen()) {
    cookieGameClick();
    return false;
  }
  if (isBubbleScreen()) {
    bubbleGameClick();
    return false;
  }
  if (screen === "home") {
    if (isOver(gamesButton)) navigateTo("games");
    else if (isOver(shopButton)) navigateTo("shop");
    else if (isOver(exitButton)) navigateTo("exit");
  }
  return false;
}

function mouseReleased() { cookieTracing = false; }

function updatePointer() {
  pointerX = (mouseX - pageX) / pageScale;
  pointerY = (mouseY - pageY) / pageScale;
}

function updatePageSize() {
  pageScale = min(width / 800, height / 600);

  pageX = (width - 800 * pageScale) / 2;
  pageY = 0;

  let leftEdge = -pageX / pageScale;
  let fullWidth = width / pageScale;
  let fullHeight = height / pageScale;

  // keeps these buttons near the edges
  homeButton.x = leftEdge + 90;
  backButton.x = leftEdge + 215;
  helpButton.x = leftEdge + fullWidth - 60;

  exitButton.x = leftEdge + 110;
  shopButton.x = leftEdge + fullWidth - 110;

  exitButton.y = fullHeight - 65;
  shopButton.y = fullHeight - 65;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  updatePageSize();
}

// Integrated wallpaper shop
// Shop
let stars = 10; // UI mirror of TeamStars; refreshed each frame
let message = "Welcome to the Star Shop!";
let equipped = -1;
let currentPage = 0;
let starImg = null;

let items = [
  { name: "Night Sky", price: 3, file: "animals.jpg", owned: false, img: null },
  { name: "Animals", price: 3, file: "nightSky.jpg", owned: false, img: null },
  { name: "Space", price: 3, file: "space.png", owned: false, img: null },
  { name: "Dinosaurs", price: 3, file: "dino.png", owned: false, img: null },
  { name: "Car", price: 3, file: "car.jpg", owned: false, img: null },
  { name: "Rainbow", price: 3, file: "rainbow.jpg", owned: false, img: null },
  { name: "Planes", price: 3, file: "planes.jpg", owned: false, img: null },
  { name: "Whimsical", price: 3, file: "whimsical.jpg", owned: false, img: null }
];

const UI_WIDTH = 800;
const UI_HEIGHT = 600;

// Shop animations
let buttonSizes = Array(8).fill(1);
let shopHomeButtonSize = 1;
let pageButtonSize = 1;

let flyingStars = [];
let purchaseAnimation = false;
let purchasingItem = -1;
let purchaseTimer = 0;
let celebrationTimer = 0;

// Prevent clicking through screens





function loadShopImages() {
  loadImage(
    "assets/star.png",
    img => starImg = img,
    err => console.error("Failed to load star.png", err)
  );

  for (let item of items) {
    loadImage(
      "assets/" + item.file,
      img => item.img = img,
      err => console.error("Failed to load " + item.file, err)
    );
  }
}


function drawMainBackground() {
  background(cream);
  if (equipped >= 0 && equipped < items.length && items[equipped].img) {
    const img = items[equipped].img;
    const s = max(width / img.width, height / img.height);
    imageMode(CORNER);
    image(img, (width-img.width*s)/2, (height-img.height*s)/2, img.width*s, img.height*s);
  }
}

function insideButton(x,y,w,h) {
  return pointerX >= x && pointerX <= x+w && pointerY >= y && pointerY <= y+h;
}
function drawShop() {
  rectMode(CORNER);
  imageMode(CORNER);
  textAlign(CENTER, CENTER);

  // Full-width navigation bar consistent with the homepage
  drawTopBar("Star shop", true);

  // Stars balance
  fill(255);
  stroke(45, 70, 105);
  strokeWeight(2);
  rect(550, 78, 235, 42, 12);

  if (starImg) {
    image(starImg, 567, 86, 25, 25);
  } else {
    fill(yellow);
    stroke(navy);
    drawStar(579, 99, 6, 12);
  }

  noStroke();
  fill(45, 70, 105);
  textSize(18);
  textStyle(BOLD);
  text("Stars: " + stars, 690, 99);

  // Shop title
  fill(255);
  stroke(45, 70, 105);
  strokeWeight(2);
  rect(300, 80, 200, 52, 15);

  noStroke();
  fill(45, 70, 105);
  textSize(36);
  textStyle(BOLD);
  text("SHOP", 400, 106);

  // Wallpaper cards
  let startIndex = currentPage * 4;
  let endIndex = min(startIndex + 4, items.length);

  for (let i = startIndex; i < endIndex; i++) {
    let position = i - startIndex;
    let x = 27.5 + position * 195;
    let y = 150;

    // Card
    fill(255);
    stroke(45, 70, 105);
    strokeWeight(2);
    rect(x, y, 175, 310, 15);

    // Wallpaper preview
    drawWallpaperPreview(
      items[i].img,
      x + 15,
      y + 15,
      145,
      155
    );

    // Name
    noStroke();
    fill(45, 70, 105);
    textSize(18);
    textStyle(BOLD);
    text(items[i].name, x + 87.5, y + 190);

    // Price
    if (starImg) {
      image(starImg, x + 38, y + 208, 25, 25);
    } else {
      fill(yellow);
      stroke(navy);
      drawStar(x + 50, y + 220, 6, 12);
    }

    noStroke();
    fill(45, 70, 105);
    textSize(17);
    text(items[i].price + " Stars", x + 105, y + 220);

    // Button hover
    let hovered = insideButton(x + 20, y + 245, 135, 45);

    buttonSizes[i] = lerp(
      buttonSizes[i],
      hovered && !purchaseAnimation ? 1.12 : 1,
      0.2
    );

    let buttonColor;
    let buttonText;

    if (equipped === i) {
      buttonColor = color(130, 200, 140);
      buttonText = "Equipped";
    } else if (items[i].owned) {
      buttonColor = color(115, 160, 255);
      buttonText = "Equip";
    } else {
      buttonColor = color(160, 225, 100);
      buttonText = "Buy";
    }

    if (purchaseAnimation && purchasingItem === i) {
      buttonColor = color(255, 205, 90);
      buttonText = "Buying...";
    }

    if (celebrationTimer > 0 && purchasingItem === i) {
      buttonColor = color(255, 225, 100);
    }

    drawAnimatedButton(
      x + 87.5,
      y + 267.5,
      135,
      45,
      buttonSizes[i],
      buttonColor,
      buttonText,
      17
    );
  }

  // Message bubble
  fill(255);
  stroke(45, 70, 105);
  strokeWeight(2);
  rect(190, 490, 420, 65, 15);

  noStroke();
  fill(45, 70, 105);
  textSize(20);
  textStyle(BOLD);
  text(message, 400, 522);

  // More / Previous
  let pageX = 650;
  let pageHover = insideButton(pageX, 535, 140, 45);

  pageButtonSize = lerp(
    pageButtonSize,
    pageHover && !purchaseAnimation ? 1.1 : 1,
    0.2
  );

  let pageText = currentPage === 0
    ? "More →"
    : "← Previous";

  drawAnimatedButton(
    pageX + 70,
    557.5,
    140,
    45,
    pageButtonSize,
    color(115, 214, 231),
    pageText,
    17
  );

  noStroke();
  fill(45, 70, 105);
  textSize(16);
  textStyle(BOLD);
  text("Page " + (currentPage + 1) + " / 2", 400, 575);

  // Animations
  updateFlyingStars();

  if (purchaseAnimation) {
    purchaseTimer++;

    if (purchaseTimer >= 65) {
      finishPurchase();
    }
  }

  if (celebrationTimer > 0) {
    celebrationTimer--;
  }
}


// ======================================
// WALLPAPER PREVIEWS
// ======================================

function drawWallpaperPreview(img, x, y, w, h) {
  rectMode(CORNER);
  imageMode(CORNER);

  if (!img) {
    noStroke();
    fill(230);
    rect(x, y, w, h, 8);

    fill(100);
    textSize(15);
    textStyle(NORMAL);
    text("Loading...", x + w / 2, y + h / 2);
    return;
  }

  let s = min(w / img.width, h / img.height);

  let drawW = img.width * s;
  let drawH = img.height * s;

  noStroke();
  fill(245);
  rect(x, y, w, h, 6);

  image(
    img,
    x + (w - drawW) / 2,
    y + (h - drawH) / 2,
    drawW,
    drawH
  );
}


// ======================================
// SHOP ANIMATED BUTTONS
// ======================================

function drawAnimatedButton(
  cx, cy, w, h, size, buttonColor, label, fontSize
) {
  push();

  translate(cx, cy);
  rectMode(CORNER);

  let sw = w * size;
  let sh = h * size;

  noStroke();
  fill(45, 70, 105, 45);
  rect(-sw / 2 + 2, -sh / 2 + 4, sw, sh, 12);

  fill(buttonColor);
  stroke(45, 70, 105);
  strokeWeight(2);
  rect(-sw / 2, -sh / 2, sw, sh, 12);

  noStroke();
  fill(45, 70, 105);
  textAlign(CENTER, CENTER);
  textSize(fontSize * size);
  textStyle(BOLD);
  text(label, 0, 0);

  pop();
}


// ======================================
// PURCHASE ANIMATION
// ======================================

function startPurchase(i) {
  if (purchaseAnimation) return;
  if (items[i].owned) return;
  if (stars < items[i].price) return;

  purchaseAnimation = true;
  purchasingItem = i;
  purchaseTimer = 0;
  flyingStars = [];

  let position = i - currentPage * 4;

  let targetX = 27.5 + position * 195 + 87.5;
  let targetY = 417.5;

  for (let j = 0; j < items[i].price; j++) {
    flyingStars.push({
      startX: 662,
      startY: 27,
      targetX,
      targetY,
      delay: j * 10,
      size: 35
    });
  }

  message = "Purchasing " + items[i].name + "...";
}

function updateFlyingStars() {
  for (let s of flyingStars) {
    if (purchaseTimer < s.delay) continue;

    let t = constrain(
      (purchaseTimer - s.delay) / 40,
      0,
      1
    );

    let smoothT = t * t * (3 - 2 * t);

    let x = lerp(s.startX, s.targetX, smoothT);
    let y = lerp(s.startY, s.targetY, smoothT);

    y -= sin(t * PI) * 90;

    let size = lerp(s.size, 12, smoothT);

    if (t < 1) {
      if (starImg) {
        image(
          starImg,
          x - size / 2,
          y - size / 2,
          size,
          size
        );
      } else {
        noStroke();
        fill(255, 220, 0);
        ellipse(x, y, size, size);
      }
    }
  }
}

function finishPurchase() {
  let i = purchasingItem;

  if (i < 0 || i >= items.length) {
    purchaseAnimation = false;
    return;
  }

  if (!items[i].owned && TeamStars.spend(items[i].price)) {
    stars = TeamStars.balance();
    items[i].owned = true;
    equipped = i;

    message = "Purchased " + items[i].name + "!";
    celebrationTimer = 25;

    saveShop();
  }

  purchaseAnimation = false;
  flyingStars = [];
}


// ======================================
// SHOP INTERACTIONS
// ======================================

function handleShopClick() {
  if (purchaseAnimation) return;

  // Return to Home
  if (isOver(homeButton)) {
    screen = "home";
    return;
  }

  // More / Previous
  if (insideButton(650, 535, 140, 45)) {
    currentPage = currentPage === 0 ? 1 : 0;

    message = currentPage === 0
      ? "Welcome to the Star Shop!"
      : "More wallpapers!";

    return;
  }

  // Wallpaper buttons
  let startIndex = currentPage * 4;
  let endIndex = min(startIndex + 4, items.length);

  for (let i = startIndex; i < endIndex; i++) {
    let position = i - startIndex;
    let x = 27.5 + position * 195;

    if (insideButton(x + 20, 395, 135, 45)) {
      if (equipped === i) {
        message = "Already equipped!";
      } else if (items[i].owned) {
        equipped = i;
        message = "Equipped " + items[i].name + "!";
        saveShop();
      } else if (stars >= items[i].price) {
        startPurchase(i);
      } else {
        message = "Not enough stars!";
      }

      return;
    }
  }
}


function saveShop() {
  stars = TeamStars.balance();
  try {
    localStorage.setItem(
      "shopSave",
      JSON.stringify({
        stars: stars,
        equipped: equipped,
        owned: items.map(item => item.owned)
      })
    );
  } catch (error) {
    console.error("Save error:", error);
  }
}

function loadShopSave() {
  try {
    let saved = localStorage.getItem("shopSave");

    if (saved) {
      let data = JSON.parse(saved);

      stars = TeamStars.balance();
      equipped = data.equipped ?? -1;

      if (Array.isArray(data.owned)) {
        for (let i = 0; i < items.length; i++) {
          items[i].owned = data.owned[i] ?? false;
        }
      }
    }
  } catch (error) {
    console.error("Save loading error:", error);
  }

  if (
    equipped < 0 ||
    equipped >= items.length ||
    !items[equipped].owned
  ) {
    equipped = -1;
  }
}

function isCookieScreen() {
  return ["cookieMenu","cookieShapes","cookieTutorial","cookieAchievements","cookiePlay","cookieFinish","cookieFail"].includes(screen);
}
function isBubbleScreen() {
  return ["bubbleMenu","bubbleLevels","bubbleTutorial","bubbleAchievements","bubbleSettings","bubblePlay","bubbleFinish"].includes(screen);
}
